//
//  CustomCell.swift
//  sample1
//
//  Created by yiming zhao on 20/11/18.
//  Copyright © 2018 yiming zhao. All rights reserved.
//

import Foundation
import UIKit
class CustomCell: UITableViewCell{
    
    @IBOutlet weak var address: UILabel!
    @IBOutlet weak var restaurantName: UILabel!
    @IBOutlet weak var backgroundImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
    }
}
