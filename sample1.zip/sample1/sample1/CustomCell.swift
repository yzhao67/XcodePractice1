//
//  CustomCell.swift
//  sample1
//
//  Created by yiming zhao on 20/11/18.
//  Copyright © 2018 yiming zhao. All rights reserved.
//

import Foundation
import UIKit
class CustomCell: UITableViewCell{
    
    @IBOutlet weak var address: UILabel!
    @IBOutlet weak var restaurantName: UILabel!
    @IBOutlet weak var backgroundImage: UIImageView!
    
   
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
}
extension UIImageView{
    func addBlackGradientLayer(frame: CGRect, colors:[UIColor]){
        let gradient = CAGradientLayer()
        gradient.frame = frame
        gradient.colors = colors.map{$0.cgColor}
        self.layer.addSublayer(gradient)
    }
}
