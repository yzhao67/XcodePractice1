//
//  RestaurantDataModel.swift
//  sample1
//
//  Created by yiming zhao on 20/11/18.
//  Copyright © 2018 yiming zhao. All rights reserved.
//

import Foundation
import UIKit
class RestaurantDataModel{
    //set variables
    var restaurantName :String = ""
    var address:String = ""
    var image : UIImage? = nil
    var imageUrl : URL? = nil
}
