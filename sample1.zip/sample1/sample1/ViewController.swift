//
//  ViewController.swift
//  sample1
//
//  Created by yiming zhao on 19/11/18.
//  Copyright © 2018 yiming zhao. All rights reserved.
//

import UIKit
import CoreLocation
import Alamofire
import SwiftyJSON
struct CellData {
    let image :  UIImage?
    let message: String?
}
class ViewController: UIViewController, UITableViewDataSource,UITableViewDelegate, CLLocationManagerDelegate  {
    
    
    //var data = [CellData]()
    @IBOutlet weak var locationLabel: UILabel!
    @IBOutlet weak var table: UITableView!
    let restaurantDataModel = RestaurantDataModel()
    let APP_ID = "d60baba45e8f0144e4487a4dc99b18cd"
    let url = "https://developers.zomato.com/api/v2.1/geocode"
    let headers : HTTPHeaders = ["user-key": "d60baba45e8f0144e4487a4dc99b18cd", "Accept": "application/json"]
    let locationManager = CLLocationManager()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        // set up the location mananger here
        //data = [CellData.init(image: nil, message: "aSassaSasaSa")]
       
        
        
        table.register(UINib(nibName: "cellsample", bundle: nil),forCellReuseIdentifier:"CustomCell")
        table.dataSource = self
        table.delegate = self
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        locationManager.startUpdatingLocation()
       configureTableView()
        
    }
    //get zomato data
    func getZomatoData(url: String, parameters:[String:String] ){
        Alamofire.request(url, method: .get, parameters:parameters,headers: headers).responseJSON{
            response in
            if response.result.isSuccess{
                print("Success! got the weather data")
                let informationJSON :JSON = JSON(response.result.value!)
                self.updateRestaurantData(json: informationJSON)
               print(informationJSON)
               // print(parameters)
            }
            else{
                print("error\(response.result.error)")
                self.locationLabel.text = "Connection Issues"
            }
            
        }
    }
 //location manager delegate method
    //did update location method
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let location = locations[locations.count-1]
        if location.horizontalAccuracy > 0{
            locationManager.stopUpdatingLocation()
            locationManager.delegate = nil
            print("longitude = \(location.coordinate.longitude), latitude = \(location.coordinate.latitude)")
            //find the position
            //let latitude = String(location.coordinate.latitude)
            //let longitude = String(location.coordinate.longitude)
            //default position in victoria
            let latitude = String(-37.803)
            let longitude = String(145.002)
            let params :[String: String] = ["user-key" : APP_ID,"lon" : longitude,"lat": latitude]
            getZomatoData(url: url, parameters:params)
        }
    }
 //did fail with error method
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error)
        locationLabel.text = "Location Unavaliable"
    }
    //update the JSON
    func updateRestaurantData(json:JSON){
        let RestaurantName = json["nearby_restaurants"][0]["restaurant"]["name"].string
        restaurantDataModel.restaurantName = RestaurantName!
        let location = json["location"]["title"].string
        let address = json["nearby_restaurants"][0]["restaurant"]["address"].string
        
        let restImage = json["nearby_restaurants"][0]["restaurant"]["featured_image"].url
        restaurantDataModel.imageUrl = restImage!
        restaurantDataModel.location = location!
        restaurantDataModel.address = address!
        //restaurantDataModel.image = restImage
        print(location)
    }
    //update interface
    func updateUIWithWeatherData(){
        locationLabel.text = restaurantDataModel.location
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CustomCell", for: indexPath) as! CustomCell
        cell.restaurantName.text =  restaurantDataModel.restaurantName
        cell.address.text = restaurantDataModel.address
        let data:NSData = try! NSData(contentsOf: restaurantDataModel.imageUrl!)

        cell.backgroundImage.image = UIImage(data: data as Data)
        return cell
    }
    func configureTableView(){
        table.estimatedRowHeight = 120
    }
}

