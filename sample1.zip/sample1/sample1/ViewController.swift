//
//  ViewController.swift
//  sample1
//
//  Created by yiming zhao on 19/11/18.
//  Copyright © 2018 yiming zhao. All rights reserved.
//

import UIKit
import CoreLocation
import Alamofire
import SwiftyJSON
import SDWebImage
class ViewController: UIViewController, UITableViewDataSource,UITableViewDelegate, CLLocationManagerDelegate  {
    
    
    @IBOutlet weak var tableView: UITableView!
    //var data = [CellData]()


    var Rests: [RestaurantDataModel] = []
    let APP_ID = "d60baba45e8f0144e4487a4dc99b18cd"
    let url = "https://developers.zomato.com/api/v2.1/geocode"
    let sampleTest = ["asdasd","abdbdb","qweqwe"]
    let headers : HTTPHeaders = ["user-key": "d60baba45e8f0144e4487a4dc99b18cd", "Accept": "application/json"]
    //let locationManager = CLLocationManager()
    let latitude = String(-37.803)
    let longitude = String(145.002)
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        // set up the location mananger here
       
        //locationManager.delegate = self
        //locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters
        //locationManager.requestWhenInUseAuthorization()
        //locationManager.startUpdatingLocation()
        let params :[String: String] = ["user-key" : APP_ID,"lon" : longitude,"lat": latitude]

        getZomatoData(url: url, parameters:params, Rests: Rests)
        
    }
    //get zomato data
    func getZomatoData(url: String, parameters:[String:String], Rests: [RestaurantDataModel] ){
        Alamofire.request(url, method: .get, parameters:parameters,headers: headers).responseJSON{
            response in
            if response.result.isSuccess{
                print("Success! got the restaurant data")
                let informationJSON :JSON = JSON(response.result.value!)
                self.updateRestaurantData(json: informationJSON,number: 0)
                self.updateRestaurantData(json: informationJSON,number: 1)
                self.updateRestaurantData(json: informationJSON,number: 2)
                self.updateRestaurantData(json: informationJSON,number: 3)
                self.updateRestaurantData(json: informationJSON,number: 4)
                self.updateRestaurantData(json: informationJSON,number: 5)
                self.updateRestaurantData(json: informationJSON,number: 6)
                self.updateRestaurantData(json: informationJSON,number: 7)
                self.updateRestaurantData(json: informationJSON,number: 8)
                  print(self.Rests)
                print(self.Rests[0].imageUrl)
               //print(informationJSON)
               // print(parameters)
            }
            else{
                print("error\(response.result.error)")
               // self.locationLabel.text = "Connection Issues"
            }
            
        }
    }
 //location manager delegate method
    //did update location method
   // func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
     //   let location = locations[locations.count-1]
       // if location.horizontalAccuracy > 0{
         //   locationManager.stopUpdatingLocation()
           // locationManager.delegate = nil
            //print("longitude = \(location.coordinate.longitude), latitude = \(location.coordinate.latitude)")
            //find the position
            //let latitude = String(location.coordinate.latitude)
            //let longitude = String(location.coordinate.longitude)
            //default position in victoria
            //let latitude = String(-37.803)
            //let longitude = String(145.002)
            //let params :[String: String] = ["user-key" : APP_ID,"lon" : longitude,"lat": latitude]
            //getZomatoData(url: url, parameters:params, Rests: Rests)
        //}
   // }
 //did fail with error method
   // func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        //print(error)
       // locationLabel.text = "Location Unavaliable"
    //}
    //update the JSON
    func updateRestaurantData(json:JSON, number: Int){
         let restaurantDataModel = RestaurantDataModel()
        let RestaurantName = json["nearby_restaurants"][number]["restaurant"]["name"].stringValue
        restaurantDataModel.restaurantName = RestaurantName
        let address = json["nearby_restaurants"][number]["restaurant"]["location"]["address"].stringValue
        
        let restImage = json["nearby_restaurants"][number]["restaurant"]["featured_image"].url
         restaurantDataModel.imageUrl = restImage
       
          restaurantDataModel.address = address
        //restaurantDataModel.image = restImage
        
        self.Rests.append(restaurantDataModel)
        self.tableView.reloadData()
        //print(Rests)
        //print(location)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return (self.Rests.count)
        //return sampleTest.count
        //return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CustomCell", for: indexPath) as! CustomCell
        cell.restaurantName.text =  self.Rests[indexPath.row].restaurantName
        cell.backgroundImage.sd_setImage(with: self.Rests[indexPath.row].imageUrl)  
        //cell.restaurantName.text = sampleTest[indexPath.row]
        cell.address.text = Rests[indexPath.row].address
        //cell.backgroundImage.sd_setImage()
        //let data:NSData = try! NSData(contentsOf: restaurantDataModel.imageUrl!)
        cell.backgroundImage.addBlackGradientLayer(frame: view.bounds, colors:[.clear, .black])
       // cell.backgroundImage.image = UIImage(data: data as Data)
        return cell
    }
}

